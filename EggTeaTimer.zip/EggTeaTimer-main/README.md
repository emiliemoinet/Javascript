# EggTeaTimer - Projet Svelte 

Membres du groupe :  Marion Dieudonné, Maria Guy De Fontgalland, Lucas Sabathe, Emilie Moinet

## Pour faire tourner le projet ...

Installez les modules après que vous êtes dans le dossier du projet (dans le terminal) 

```bash
npm install
```

puis lancez le projet 

```bash
npm run dev 
```

ensuite dans un autre onglet du terminal, déplacez vous dans le dossier api et lancez le serveur que l'on a crée 

```bash
cd api
node app.js
```

enfin allez sur votre navigateur et allez sur cette page : localhost:8080


## Sujet pour rappel
Le site doit afficher les recettes et timers animés pour thé et œuf, à la manière de la démo proposée de timer pour café et ce en utilisant du Svelte. 
 
