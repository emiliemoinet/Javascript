<script>
	import Header from './components/Header.svelte';
	import Routes from './components/Routes.svelte';
	import Footer from './components/Footer.svelte';
</script>

<Header/>
<Routes/>
<Footer/>
