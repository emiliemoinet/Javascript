<footer>
	<p> Group project : Marion Dieudonné, Maria guy de Fontgalland, Lucas Sabathe, Emilie Moinet </p>
</footer>
