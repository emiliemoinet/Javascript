<header class="text-center">
    <a href="/">
        <h1 class="text-green title fw-bold">Egg’n Tea Timer</h1>
        <p>Make yourself a Tea or an Egg very easily with our instructions</p>
    </a>
</header>
